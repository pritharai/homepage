import React from "react";

const Navbar = () => {
    return (
      <nav className="bg-black text-white p-4 flex justify-between items-center">
        <div className="text-xl font-bold flex items-center">
          <img src="/logo.png" alt="PCTE Logo" className="h-8 mr-2" />
          PCTE Group of Institutes
        </div>
        <ul className="flex space-x-6">
          <li className="hover:text-gray-400 cursor-pointer">Home</li>
          <li className="hover:text-gray-400 cursor-pointer">About Us</li>
          <li className="hover:text-gray-400 cursor-pointer">Events</li>
          <li className="hover:text-gray-400 cursor-pointer">Results</li>
        </ul>
        <button className="bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700">REGISTER NOW</button>
      </nav>
    );
  };
  
  export default Navbar ;