import React from "react";

const Gallery = () => {
    const images = [
      "/conference.jpg",
      "/college.jpg",
      "/building.jpg",
      "/garden.jpg",
      "/fashion-show.jpg",
    ];
    return (
      <div className="flex justify-center space-x-4 p-6 bg-black">
        {images.map((src, index) => (
          <img key={index} src={src} alt="Gallery" className="w-40 h-32 rounded-md shadow-lg" />
        ))}
      </div>
    );
  };

  export default Gallery;