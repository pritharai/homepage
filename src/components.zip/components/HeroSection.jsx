import React from "react";

const HeroSection = () => {
    return (
      <div className="relative h-[500px] bg-cover bg-center text-white flex flex-col justify-center items-center" style={{ backgroundImage: "url('/background.jpg')" }}>
        <h1 className="text-5xl font-bold">PCTE Groups of Institutes</h1>
        <p className="text-lg mt-2">PRESENTS</p>
        <h2 className="text-4xl font-semibold mt-2">Koshish</h2>
        <button className="bg-red-600 px-6 py-3 mt-4 rounded hover:bg-red-700">CONTACT US ↗</button>
      </div>
    );
  };

  export default HeroSection;