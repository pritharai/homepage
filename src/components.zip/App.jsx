import React from "react";
import './App.css';
import Navbar from './components/Navbar';   
import HeroSection from './components/HeroSection';  
import Gallery from './components/Gallery';  

const App = () => {
  return (
    <div>
      <Navbar />
      <HeroSection />
      <Gallery />
    </div>
  );
};

export default App;
